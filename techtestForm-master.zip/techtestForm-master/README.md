techtestForm
============

Technical Test - Create Validated Form

BRIEF

Using either XHTML or HTML5, produce the markup for a simple contact form with client side validation. Use Javascript and any supporting libraries or plugins to help you.

The form must include the following fields:  First Name, Surname, Email Address, Gender Male / Female (Radio Buttons), a subject picker (select list), a message field, a disclaimer checkbox and a submit button. You must make all fields compulsory and ensure that the e-mail address is correctly formatted. If all validation is approved, once submitted, the form must disappear and be replaced with the submitted data in the style of: First Name: <first name>, etc etc.  

-- Please note that this form data does not need to be processed anywhere server side. --

ANSWER:
I used :HTML5, AngularJS and Bootsrap as CSS.
Love AngularJS :D
