# Developing elements for designers 

## Overview


#Aim:
The aim of this project is to create a template presenting the main elements of web developing used to build a website design.
In particular it has the purpose to highlight those development concepts can be useful to a team of creative designers.

#Objectives:

The template has a landing page representing a website layout showing the most required and common elements.

It has a session dedicate to describe CSS and HTML major elements showing how those works though examples.

Finally it has a session dedicate to articles or useful reading about the integration of design and developing skills to produce successful digital platform.


#Technical Overview:

The template has been developed in HTML and CSS. The landing page presents a drop-down navigation bar and a slide show both built using jQuery plug in.

The elements sessions is developed using Angolar JS and based on its tutorial : -http://docs.angularjs.org/tutorial/ - Angular JS Phone Catolog Tutorial Application.


