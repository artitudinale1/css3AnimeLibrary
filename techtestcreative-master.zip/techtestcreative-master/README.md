techtestcreative
================

Technical test - creative

BRIEF:
 Creative license. A large part of your role will be introducing finishing touches to interfaces that cannot be conveyed in flat design files. 

Please see the 'Nav.psd' file in the 'Creative' folder supplied with this test package. Using any of the following technologies (HTML,CSS,JavaScript), reproduce the navigation bar illustrated in the 'Nav.psd' file. Feel free to use your creativity and imagination to add any additional effects / design touches.

If you don't have photoshop, use an alternative such as Gimp or Pixelmator. Failing that we have included a JPG as a build reference.

Key files: Nav.psd , Nav.jpg

MY ANSWER: 
I used :HTML5, CSS3 and JS.
I've interpreted the functionality as an accordion menu.
I was attracted by the numbers next to each tabs and I wanted give dynamic values so I just linked those to counters of hits on the same tabs. Probably it wouldn't work in browser that are not supporting CSS3.
